# Bugs

- [ ] 

# ToDo

- [ ] Start with `Database-Manager`
  - [ ] Create database for weather info
    - [x] Try to Create
  - [ ] Save weather info into database
  - [ ] ??Helper Class, `WeatherToDisplay` (needs to be discussed with Tim)??
  
- [ ] Finish `API-Manager` (should be static, but for now its not a static class)
  - [x] Exceptions for different errors


# Log

## 08-04-2022 - Friday

- [Organisation] organising project folder/files/ ... on gitlab
- [Organisation] https://openweathermap.org/weather-conditions#Weather-Condition-Codes-2 ... Icons for different weather

## 13-04-2022 - Wednesday (Easter Holidays)
- [Python Script] Installed Pycharm -> Convert Cities (JSON-File) to SQLite-File -> Try to req.
- [Python Script] Converting into SQLite-File --> \2h

## 14-04-2022 - Thursday (Easter Holidays)
- [WeatherInfoModel] Model for weather information `weatherInfoModel `--> \1/2h
- [API-Manager] Start with `API-Manager` --> \1/2h

## 15-04-2022 - Friday (Easter Holidays --> nothing on this day)

## 22-04-2022 - Friday
- [JSONModel] JSON Converter --> https://github.com/kerminator-dev/WeatherWidget/blob/main/src/WeatherWidget/WeatherWidget/Models/JSON/OpenWeatherJSON.cs change code to my needs \2h
- [WeatherInfoListModel] Model for weather information `weatherInfoListModel`
- TO DO: Pflichtenheft, UI-Entwürfe, Aufteilung Arbeitspakete, Klassendiagramme, ER-Diagramme


till 02.05 --> per E-Mail
## 23-04-2022 - Saturday
- [API-Manager, JSONModel] Working on API-Manager, JSON-Converter

## 29-04-2022 - Friday
- [Organisation] finishing `Pflichtenheft.md`, documentation `LogBookMikail.md` --> \2h
- [WeatherInfoModel] update on `WeatherInfoModel` --> \1/4h (String for wind direction)

## 30-04-2022 - Saturday

- [Organisation] documentation: ER-Diagram, Class-Diagram --> \2h
- [API-Manager] work on exceptions for different errors --> \2h
  - Try and Catch
- [DataBaseManager] new Branch, new Class -->\1/4h
  - [DataBaseManager] Save into DataBase (try, not final) --> \1,5h
